package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class Trade {
    public static void main(String[] args) {
        // Setup ChromeDriver using WebDriverManager
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Open login page
            driver.get("http://localhost:5173/login");
            driver.manage().window().maximize();

            // Wait for email input field to be visible
            WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div/div[2]/div/form/div[1]/input")));
            emailField.sendKeys("overclocklyrics@gmail.com");

            // Wait for password input field to be visible and enter password
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div/div[2]/div/form/div[2]/input")));
            passwordField.sendKeys("demo123");

            // Click login button
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/form/div[3]/button")));
            loginButton.click();

            // Wait for login to complete
            wait.until(ExpectedConditions.urlContains("/"));

            System.out.println("Login successful");

            // Click on "All Trade" button in the navbar
            WebElement allTradeButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/nav/div/div/div[1]/div/a[2]")));
            allTradeButton.click();


            // Click on "A Trade" button (first trade row in the table)
            WebElement tradeButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/main/div/div[2]/table/tbody/tr[1]/td[1]")));
            tradeButton.click();

            // Wait for a few seconds to view the trade details
            Thread.sleep(5000); // View the trade for 5 seconds

            System.out.println("Trade viewed successfully");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
