package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Signup {
    public static void main(String[] args) {
        // Setup ChromeDriver using WebDriverManager
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        try {
            // Open the registration page
            driver.get("http://localhost:5173/register");
            driver.manage().window().maximize();

            // Locate email and password fields and register button
            WebElement emailField = driver.findElement(By.xpath("/html/body/div/div/div/form/div[1]/div[1]/input"));
            WebElement passwordField = driver.findElement(By.xpath("/html/body/div/div/div/form/div[1]/div[2]/input"));
            WebElement registerButton = driver.findElement(By.xpath("/html/body/div/div/div/form/div[2]/button[1]"));

            // Enter credentials and click register
            emailField.sendKeys("overclocklyrics@gmail.com");
            passwordField.sendKeys("demo123");
            registerButton.click();

            // Wait for registration to process
            Thread.sleep(2000);

            // Redirect to login manually
            driver.get("http://localhost:5173");

            System.out.println("Registration test completed successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}