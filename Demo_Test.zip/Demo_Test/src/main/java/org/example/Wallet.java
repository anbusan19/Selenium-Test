package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class Wallet {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.get("http://localhost:5173/login");
            driver.manage().window().maximize();

            // Wait for email input field to be visible
            WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div/div[2]/div/form/div[1]/input")));
            emailField.sendKeys("overclocklyrics@gmail.com");

            // Wait for password input field to be visible and enter password
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div/div[2]/div/form/div[2]/input")));
            passwordField.sendKeys("demo123");

            // Click login button
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/form/div[3]/button")));
            loginButton.click();

            // Wait for login to complete
            wait.until(ExpectedConditions.urlContains("/"));

            System.out.println("Login successful");


            // Navigate to Dashboard
            WebElement dashboardButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/nav/div/div/div[3]/div/div/a[1]")));  // Adjust XPath
            dashboardButton.click();

            // Click on "Deposit" button
            WebElement depositButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/main/div/div/div[1]/div/div[1]/button")));  // Adjust XPath
            depositButton.click();

            // Enter value into the deposit amount field
            WebElement depositAmountField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/main/div/div/div[1]/div/div[3]/div/form/div[1]/input")));  // Adjust XPath
            depositAmountField.sendKeys("200");

            // Click "Confirm" button
            WebElement confirmButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/main/div/div/div[1]/div/div[3]/div/form/div[2]/button[2]")));  // Adjust XPath
            confirmButton.click();

            Thread.sleep(5000);

            System.out.println("Deposit successful");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
