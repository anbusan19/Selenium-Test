package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;

public class CreateTrade {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.get("http://localhost:5173/login");
            driver.manage().window().maximize();

            // Wait for email input field to be visible
            WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div/div[2]/div/form/div[1]/input")));
            emailField.sendKeys("overclocklyrics@gmail.com");

            // Wait for password input field to be visible and enter password
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div/div[2]/div/form/div[2]/input")));
            passwordField.sendKeys("demo123");

            // Click login button
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/form/div[3]/button")));
            loginButton.click();

            // Wait for login to complete
            wait.until(ExpectedConditions.urlContains("/"));

            System.out.println("Login successful");


            WebElement createTradeButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/nav/div/div/div[3]/a/span")));  // Adjust the XPath
            createTradeButton.click();

            // Enter data into the 'amount' field
            WebElement amountField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/main/div/form/div[3]/input")));  // Adjust XPath
            amountField.sendKeys("500");

            // Enter data into the 'price' field
            WebElement priceField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/main/div/form/div[4]/input")));  // Adjust XPath
            priceField.sendKeys("650");

            // Click the 'Make Trade' button
            WebElement makeTradeButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/main/div/form/button")));  // Adjust XPath
            makeTradeButton.click();

            Thread.sleep(5000);

            System.out.println("Trade created successfully");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
